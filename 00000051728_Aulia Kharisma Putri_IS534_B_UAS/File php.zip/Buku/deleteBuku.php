<?php
header('Content-type:application/json;charset=utf-8');
include "conn.php";


if(isset($_POST['nama'])){
    $nama=$_POST['nama'];

    $q=mysqli_query($connect,"DELETE FROM item WHERE nama='$nama'");
    $response=array();

    if($q){
        $response["success"]=1;
        $response["message"]="Data berhasil delete";
        echo json_encode($response);
    }else{
        $response["success"]=0;
        $response["message"]="data gagal di hapus";
        echo json_encode($response);
    }
}else{
    $response["success"]=-1;
    $response["message"]="Data kosong";
    echo json_encode($response);
}
?>