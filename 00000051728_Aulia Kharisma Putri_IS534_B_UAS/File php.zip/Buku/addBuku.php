<?php
header('Content-type:application/json;charset=utf-8');
include 'conn.php';

$response = [];


if(isset($_POST['nama']) && isset($_POST['penulis']) && isset($_POST['toko'])){
    $nama = $_POST['nama'];
    $penulis = $_POST['penulis'];
    $rate = $_POST['toko'];

    $q = mysqli_query($connect, "INSERT INTO item(nama, penulis, toko) VALUES ('$nama', '$penulis', '$toko')");

    if($q){
        $response['success'] = 1;
        $response['message'] = "Data berhasil ditambah";
    } else {
        $response['success'] = 0;
        $response['message'] = "Data gagal ditambah";
    }
}

else {
    $response['success'] = 1;
    $response['message'] = "Data kosong";
}

echo json_encode($response);

?>
