<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";
    


 if(isset($_POST['nama']) && isset($_POST['penulis']) && isset($_POST['toko'])){
        $toko=$_POST['toko'];
        $nama=$_POST['nama'];



        $q=mysqli_query($connect,"UPDATE item set nama='$nama', toko='$toko'");
        $response=array();

        if($q){
            $response["success"]=1;
            $response["message"]="Data berhasil diupdate";
            echo json_encode($response);
        }else{
            $response["success"]=0;
            $response["message"]="data gagal diupdate";
            echo json_encode($response);
        }
    }else{
        $response["success"]=-1;
        $response["message"]="Data kosong";
        echo json_encode($response);
    }
?>