<?php

$server = "localhost"; //Sesuaikan alamat server
$user = "root";//Sesuaikan user web server
$password = "";//Sesuaikan password web server
$database = "buku";//Sesuaikan database web server

$connect = mysqli_connect($server, $user, $password) or die ("Koneksi gagal!");
mysqli_select_db($connect, $database) or die ("Database belum siap!");

?>