<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";
        
    $q=mysqli_query($connect,"SELECT * FROM item");
    $response = array();

    if(mysqli_num_rows($q)>0){
        $response["data"] = array();
        while($r=mysqli_fetch_array($q)){
            $item = array();
            $item["nama"] = $r["nama"];
            $item["penulis"] = $r["penulis"];
            $item["toko"] = $r["toko"];
            array_push($response["data"], $item);
        }
        $response["success"] = 1;
        $response["message"] = "Data buku berhasil ditampilkan";
        echo json_encode($response);
    }
    else{
        $response["success"] = 0;
        $response["message"] = "Tidak ada buku tertampil";
        echo json_encode($response);
    }
?>